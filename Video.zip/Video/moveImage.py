import shutil
import os
import time

# time.sleep(10)

os.system("mkdir output")
shutil.move("C:/Users/huzai/Desktop/Video/imgs/00001_I5.png", "C:/Users/huzai/Desktop/Video/output")